﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

public partial class Registration : System.Web.UI.Page
{
  /*  protected void Page_Load(object sender, EventArgs e)
    {

    }*/
    protected void buttonCreateAccount_Click(object sender, EventArgs e)
    {
 

        MySqlConnection Connection = new MySqlConnection("server=localhost;port=3306;username=root;password=;database=csharp_users_db");
        MySqlCommand command = new MySqlCommand("INSERT INTO `users`(`firstname`, `lastname`, `emailaddress`, `username`, `password`) VALUES (@fn, @ln, @email, @usn, @pass)", Connection);

        command.Parameters.AddWithValue("@fn", textBoxFirstname.Text);
        command.Parameters.AddWithValue("@ln", textBoxLastname.Text);
        command.Parameters.AddWithValue("@usn", ComputeSha256Hash(textBoxUsername.Text));
        command.Parameters.AddWithValue("@email", textBoxEmail.Text);
        command.Parameters.AddWithValue("@pass", ComputeSha256Hash(textBoxPassword.Text));

        // open the connection
        Connection.Open();

        // check if the textboxes contains the default values 
        // if (!checkTextBoxesValues())
        //{
        // check if the password equal the confirm password
        if (textBoxPassword.Text.Equals(textBoxPasswordConfirm.Text))
        {
            //if (textBoxPassword.Text.Length < 8 || !textBoxPassword.Text.Any(char.IsUpper) || textBoxPassword.Text.Contains(" "))
            if(!ValidatePassword(textBoxPassword.Text))
            {
                LabelMessage.Text = "Weak Password!!!";
                
            }
/*            else if(textBoxPassword.Text.Any(char.IsUpper)){

            }*/
            else
            {
                // check if this username already exists
                if (checkUsername())
                {
                    LabelMessage.Text = "This Username Already Exists, Select A Different One";
                }
                else
                {
                    if (CheckEmail())
                    {
                        LabelMessage.Text = "This email has been used!";
                    }
                    else
                    {
                        
                        // execute the query
                        if (command.ExecuteNonQuery() == 1)
                        {
                            Literal1.Text = "Registration Successfull!";
                        }
                        else
                        {
                            LabelMessage.Text = "ERROR";
                        }
                    }
                }
            }
        }
        else
        {
            LabelMessage.Text = "Wrong Confirmation Password";
        }

        
        // close the connection
        Connection.Close();
    }


    public bool ValidatePassword(string passWord)
    {
        
        int validConditions = 0;
        foreach (char c in passWord)
        {
            if (c >= 'a' && c <= 'z')
            {
                validConditions++;
                break;
            }
    
        }
        foreach (char c in passWord)
        {
            if (c >= 'A' && c <= 'Z')
            {
                validConditions++;
                break;
            }
           
        }
        if (validConditions == 0) return false;
        foreach (char c in passWord)
        {
            if (c >= '0' && c <= '9')
            {
                validConditions++;
                break;
            }
        }
        if (validConditions == 1) return false;
        if (validConditions == 2)
        {
            char[] special = { '@', '#', '$', '%', '^', '&', '+', '=' }; // or whatever    
            if (passWord.IndexOfAny(special) == -1) return false;
          
        }
        if (passWord.Length < 8) return false;
        return true;
    }
    public Boolean checkUsername()
    {
        MySqlConnection db = new MySqlConnection("server=localhost;port=3306;username=root;password=;database=csharp_users_db");

        String username = textBoxUsername.Text;

        DataTable table = new DataTable();

        MySqlDataAdapter adapter = new MySqlDataAdapter();

        MySqlCommand command = new MySqlCommand("SELECT * FROM `users` WHERE `username` = @usn", db);

        command.Parameters.Add("@usn", MySqlDbType.VarChar).Value = username;

        adapter.SelectCommand = command;

        adapter.Fill(table);

        // check if this username already exists in the database
        if (table.Rows.Count > 0)
        {
            return true;
        }
        else
        {
            return false;
        }

    }

    public Boolean CheckEmail()
    {
        MySqlConnection db = new MySqlConnection("server=localhost;port=3306;username=root;password=;database=csharp_users_db");
        string email = textBoxEmail.Text;
        DataTable table2 = new DataTable();
        MySqlDataAdapter adapter = new MySqlDataAdapter();

        MySqlCommand command = new MySqlCommand("SELECT * FROM `users` WHERE `emailaddress` = @email", db);

        command.Parameters.Add("@email", MySqlDbType.VarChar).Value = email;

        adapter.SelectCommand = command;

        adapter.Fill(table2);

        if (table2.Rows.Count > 0 )
        {
            return true;
        }
        else return false;
    }
    public string ComputeSha256Hash(string rawData)
    {
        // Create a SHA256   
        using (SHA256 sha256Hash = SHA256.Create())
        {
            // ComputeHash - returns byte array  
            byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

            // Convert byte array to a string   
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                builder.Append(bytes[i].ToString("x2"));
            }
            return builder.ToString();
        }
    }




    protected void Page_Load(object sender, EventArgs e)
    {

    }
}