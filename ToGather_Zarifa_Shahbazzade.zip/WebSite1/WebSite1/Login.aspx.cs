﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;


public partial class Login : System.Web.UI.Page
{

    MySqlConnection Connection = new MySqlConnection("server=localhost;port=3306;username=root;password=;database=csharp_users_db");
/*    protected void Page_Load(object sender, EventArgs e)
    {
       

    }*/


    protected void buttonLogin_Click(object sender, EventArgs e)
    {
        MySqlConnection Connection = new MySqlConnection("server=localhost;port=3306;username=root;password=;database=csharp_users_db");
        //DB db = new DB();

        string username = textBoxUsername.Text;
        string password = textBoxPassword.Text;

        DataTable table = new DataTable();


        MySqlCommand command = new MySqlCommand("SELECT * FROM `users` WHERE `username` = @usn and `password` = @pass", Connection);
        MySqlDataAdapter adapter = new MySqlDataAdapter(command);

        /*command.Parameters.Add("@usn", MySqlDbType.VarChar).Value = username;
        command.Parameters.Add("@pass", MySqlDbType.VarChar).Value = password;*/
        command.Parameters.AddWithValue("@usn", ComputeSha256Hash(username));
        command.Parameters.AddWithValue("@pass", ComputeSha256Hash(password));


        adapter.Fill(table);
        Connection.Open();
        command.ExecuteNonQuery();

        // check if the user exists or not
        if (table.Rows.Count > 0)
        {
            Response.Redirect("Mainpage.aspx");
        }
        else
        {
            // check if the username field is empty
            if (username.Trim().Equals(""))
            {
                Label3.Text = "Enter Your Username To Login";
                Label3.ForeColor = System.Drawing.Color.Red;
            }
            // check if the password field is empty
            else if (password.Trim().Equals(""))
            {
                Label3.Text = "Enter Your Password To Login";
                Label3.ForeColor = System.Drawing.Color.Red;
            }

            /*else if (password.Length < 6)
            {
                Label3.Text = "Weak password!!";
                Label3.ForeColor = System.Drawing.Color.Red;
            }
*/
            // check if the username or the password don't exist
            else
            {
                Label3.Text = "Wrong Username Or Password";
                Label3.ForeColor = System.Drawing.Color.Red;
            }
        }

    }

    public string ComputeSha256Hash(string rawData)
    {
        // Create a SHA256   
        using (SHA256 sha256Hash = SHA256.Create())
        {
            // ComputeHash - returns byte array  
            byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

            // Convert byte array to a string   
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                builder.Append(bytes[i].ToString("x2"));
            }
            return builder.ToString();
        }
    }






}